import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// 开发时 /api 与 /ws 代理到本地 server（127.0.0.1:8787）
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": { target: "http://127.0.0.1:8787", changeOrigin: true },
      "/ws": { target: "ws://127.0.0.1:8787", ws: true },
    },
  },
  build: {
    outDir: "dist",
  },
});
